# USF - Portal do Utente

## Frontend setup + run
```
npm install
npm run serve
```

## Backend setup + run
```
npm install
npm start
```
