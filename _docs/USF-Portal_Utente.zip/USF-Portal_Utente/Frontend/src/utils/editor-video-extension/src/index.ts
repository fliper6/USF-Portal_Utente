import { Video } from './video'

export * from './video'

export default Video