<template>
  <div class="balcao">

    <router-link to="/balcao/medicacao">
      <div class="d-flex align-center">
        <b>Pedido de medicacao</b>
      </div>
    </router-link>

    <router-link to="/balcao/consulta">
      <div class="d-flex align-center">
        <b>Pedido de consulta</b>
      </div>
    </router-link>


    <router-link to="/balcao/sugestao">
      <div class="d-flex align-center">
        <b>Sugestão</b>
      </div>
    </router-link>

  </div>
</template>