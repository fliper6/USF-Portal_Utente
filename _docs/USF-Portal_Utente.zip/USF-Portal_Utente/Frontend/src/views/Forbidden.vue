<template>
  <div >
    <v-row align="center" justify="center">
      <span style="font-size:140px; margin-top:100px; color:var(--primary-color)">
        <b >403</b>
      </span>
    </v-row>
    <v-row align="center" justify="center">
       <b style="font-size:40px;">Oops! Não tem autorização para aceder a esta página.</b>
    </v-row>
   
  </div>
</template>

