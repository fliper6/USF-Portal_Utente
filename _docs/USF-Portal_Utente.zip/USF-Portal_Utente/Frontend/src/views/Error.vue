<template>
  <div >
    <v-row align="center" justify="center">
      <span style="font-size:140px; margin-top:100px; color:var(--primary-color)">
        <b >404</b>
      </span>
    </v-row>
    <v-row align="center" justify="center">
       <b style="font-size:40px;">Oops! Esta página não existe.</b>
    </v-row>
   
  </div>
</template>